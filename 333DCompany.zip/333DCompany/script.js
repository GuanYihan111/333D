// Global Variables
let products = [];
let cart = [];
let users = [];
let feedbacks = [];

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
  loadProducts();
  loadCart();
  loadUsers();
  loadFeedbacks();
  updateCartCount();
  
  // Initialize common elements
  initializeModal();
  initializeLightbox();
  initializeCarousel();
});

// Data Management
function loadProducts() {
  fetch('products.json')
    .then(response => response.json())
    .then(data => {
      products = data;
      if (document.getElementById('product-grid')) {
        renderProducts(products);
      }
    });
}

function loadCart() {
  const savedCart = localStorage.getItem('cart');
  cart = savedCart ? JSON.parse(savedCart) : [];
}

function saveCart() {
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
}

function loadUsers() {
  const savedUsers = localStorage.getItem('users');
  users = savedUsers ? JSON.parse(savedUsers) : [];
}

function saveUsers() {
  localStorage.setItem('users', JSON.stringify(users));
}

function loadFeedbacks() {
  const savedFeedbacks = localStorage.getItem('feedbacks');
  feedbacks = savedFeedbacks ? JSON.parse(savedFeedbacks) : [];
  if (document.getElementById('feedback-list')) {
    renderFeedbacks();
  }
}

function saveFeedbacks() {
  localStorage.setItem('feedbacks', JSON.stringify(feedbacks));
}

// Cart Functions
function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  const existingItem = cart.find(item => item.id === productId);
  
  if (existingItem) {
    if (existingItem.quantity >= product.stock) {
      showToast('Out of stock!');
      return;
    }
    existingItem.quantity++;
  } else {
    cart.push({...product, quantity: 1});
  }
  
  saveCart();
  showToast('Added to cart!');
}

function updateQuantity(productId, change) {
  const item = cart.find(item => item.id === productId);
  const product = products.find(p => p.id === productId);
  
  if (!item) return;
  
  if (change > 0 && item.quantity >= product.stock) {
    showToast('Out of stock!');
    return;
  }
  
  item.quantity += change;
  
  if (item.quantity <= 0) {
    cart = cart.filter(item => item.id !== productId);
  }
  
  saveCart();
  if (document.getElementById('cart-items')) {
    renderCart();
    calculateTotals();
  }
}

function removeFromCart(productId) {
  cart = cart.filter(item => item.id !== productId);
  saveCart();
  if (document.getElementById('cart-items')) {
    renderCart();
    calculateTotals();
  }
}

function clearCart() {
  if (confirm('Are you sure you want to clear the cart?')) {
    cart = [];
    saveCart();
    if (document.getElementById('cart-items')) {
      renderCart();
      calculateTotals();
    }
  }
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartCount = document.getElementById('cart-count');
  if (cartCount) {
    cartCount.textContent = count;
  }
}

// Render Functions
function renderProducts(productsToRender) {
  const grid = document.getElementById('product-grid');
  if (!grid) return;
  
  grid.innerHTML = '';
  productsToRender.forEach(product => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => openProductModal(product);
    
    const stockClass = product.stock < 5 ? 'low-stock' : '';
    
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>$${product.price.toFixed(2)}</p>
      <p>Category: ${product.category}</p>
      <p class="${stockClass}">Stock: ${product.stock}</p>
      <button onclick="event.stopPropagation(); addToCart(${product.id})" class="btn">Add to Cart</button>
    `;
    grid.appendChild(card);
  });
}

function renderCart() {
  const cartItems = document.getElementById('cart-items');
  if (!cartItems) return;
  
  if (cart.length === 0) {
    cartItems.innerHTML = '<p>Your cart is empty. <a href="products.html">Continue Shopping</a></p>';
    return;
  }
  
  cartItems.innerHTML = '';
  cart.forEach(item => {
    const cartItem = document.createElement('div');
    cartItem.className = 'cart-item';
    cartItem.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <div class="cart-item-details">
        <h4>${item.name}</h4>
        <p>$${item.price.toFixed(2)}</p>
      </div>
      <div class="cart-item-actions">
        <button onclick="updateQuantity(${item.id}, -1)">-</button>
        <span>${item.quantity}</span>
        <button onclick="updateQuantity(${item.id}, 1)">+</button>
        <button onclick="removeFromCart(${item.id})">Remove</button>
      </div>
    `;
    cartItems.appendChild(cartItem);
  });
}

function renderFeedbacks() {
  const feedbackList = document.getElementById('feedback-list');
  if (!feedbackList) return;
  
  feedbackList.innerHTML = '';
  feedbacks.forEach(feedback => {
    const feedbackItem = document.createElement('div');
    feedbackItem.className = 'feedback-item';
    feedbackItem.innerHTML = `
      <h4>${feedback.name}</h4>
      <p>Rating: ${'★'.repeat(feedback.rating)}</p>
      <p>${feedback.comment}</p>
    `;
    feedbackList.appendChild(feedbackItem);
  });
}

// Modal Functions
function initializeModal() {
  const modal = document.getElementById('product-modal');
  if (!modal) return;
  
  const closeModal = document.querySelector('.close-modal');
  closeModal.onclick = closeProductModal;
  
  window.onclick = function(event) {
    if (event.target === modal) {
      closeProductModal();
    }
  };
}

function openProductModal(product) {
  const modal = document.getElementById('product-modal');
  const modalContent = modal.querySelector('.modal-content');
  
  modalContent.innerHTML = `
    <span class="close-modal">&times;</span>
    <img src="${product.image}" alt="${product.name}" onclick="openLightbox('${product.image}')">
    <h2>${product.name}</h2>
    <p>$${product.price.toFixed(2)}</p>
    <p>Category: ${product.category}</p>
    <p>Stock: ${product.stock}</p>
    <p>${product.description}</p>
    <button onclick="addToCart(${product.id})" class="btn">Add to Cart</button>
  `;
  
  modal.style.display = 'block';
}

function closeProductModal() {
  const modal = document.getElementById('product-modal');
  modal.style.display = 'none';
}

// Lightbox Functions
function initializeLightbox() {
  const lightbox = document.createElement('div');
  lightbox.id = 'lightbox';
  lightbox.style.cssText = `
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.9);
    z-index: 1002;
    align-items: center;
    justify-content: center;
  `;
  
  const lightboxImg = document.createElement('img');
  lightboxImg.style.maxWidth = '90%';
  lightboxImg.style.maxHeight = '90%';
  
  lightbox.appendChild(lightboxImg);
  document.body.appendChild(lightbox);
  
  lightbox.onclick = closeLightbox;
}

function openLightbox(imageSrc) {
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = lightbox.querySelector('img');
  lightboxImg.src = imageSrc;
  lightbox.style.display = 'flex';
}

function closeLightbox() {
  const lightbox = document.getElementById('lightbox');
  lightbox.style.display = 'none';
}

// Carousel Functions
function initializeCarousel() {
  const carousel = document.getElementById('carousel');
  if (!carousel) return;
  
  const items = carousel.querySelectorAll('.carousel-item');
  let currentIndex = 0;
  
  function showSlide(index) {
    items.forEach((item, i) => {
      item.classList.remove('active');
      if (i === index) {
        item.classList.add('active');
      }
    });
  }
  
  function nextSlide() {
    currentIndex = (currentIndex + 1) % items.length;
    showSlide(currentIndex);
  }
  
  showSlide(currentIndex);
  setInterval(nextSlide, 3000);
}

// Toast Notification
function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  
  toast.style.display = 'block';
  setTimeout(() => {
    toast.style.display = 'none';
    document.body.removeChild(toast);
  }, 2000);
}

// Form Handling
function handleFeedbackSubmit(event) {
  event.preventDefault();
  const form = event.target;
  
  const feedback = {
    name: form.name.value,
    email: form.email.value,
    rating: form.rating.value,
    comment: form.comment.value
  };
  
  feedbacks.push(feedback);
  saveFeedbacks();
  renderFeedbacks();
  form.reset();
  showToast('Feedback submitted!');
}

// Admin Functions
function adminLogin() {
  // Simple admin login for demonstration
  const username = document.getElementById('admin-username').value;
  const password = document.getElementById('admin-password').value;
  
  if (username === 'admin' && password === 'password') {
    localStorage.setItem('adminLoggedIn', 'true');
    showToast('Admin logged in!');
    // Show admin features
  } else {
    showToast('Invalid credentials!');
  }
}

function addProduct(event) {
  event.preventDefault();
  const form = event.target;
  
  const newProduct = {
    id: products.length + 1,
    name: form.name.value,
    price: parseFloat(form.price.value),
    category: form.category.value,
    stock: parseInt(form.stock.value),
    image: form.image.value,
    description: form.description.value
  };
  
  products.push(newProduct);
  // In real app, you would save to JSON or backend
  renderProducts(products);
  form.reset();
  showToast('Product added!');
}

// Utility Functions
function calculateTotals() {
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const gst = subtotal * 0.10;
  const shipping = subtotal > 100 ? 0 : 10;
  const total = subtotal + gst + shipping;
  
  document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
  document.getElementById('gst').textContent = `$${gst.toFixed(2)}`;
  document.getElementById('shipping').textContent = `$${shipping.toFixed(2)}`;
  document.getElementById('total').textContent = `$${total.toFixed(2)}`;
}

// Category Filter
function filterByCategory(category) {
  if (category === 'All') {
    renderProducts(products);
  } else {
    const filteredProducts = products.filter(product => product.category === category);
    renderProducts(filteredProducts);
  }
}
